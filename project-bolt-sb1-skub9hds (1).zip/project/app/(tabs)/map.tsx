import { StyleSheet, View, Text, TouchableOpacity, Dimensions, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search } from 'lucide-react-native';
import { useState, useEffect } from 'react';

// Separate component for web map
function WebMap() {
  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d50470.12931730586!2d-122.47261171566853!3d37.75776432628234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80859a6d00690021%3A0x4a501367f076adff!2sSan%20Francisco%2C%20CA!5e0!3m2!1sen!2sus!4v1709700000000!5m2!1sen!2sus"
        style={{
          border: 0,
          width: '100%',
          height: '100%',
          position: 'absolute',
          top: 0,
          left: 0,
        }}
        allowFullScreen
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      />
    </div>
  );
}

// Separate component for native map
function NativeMap() {
  const [MapView, setMapView] = useState(null);
  const [Marker, setMarker] = useState(null);

  useEffect(() => {
    if (Platform.OS !== 'web') {
      import('react-native-maps').then((module) => {
        setMapView(() => module.default);
        setMarker(() => module.Marker);
      });
    }
  }, []);

  if (!MapView || !Marker) {
    return (
      <View style={[styles.map, styles.fallbackContainer]}>
        <Text style={styles.fallbackText}>Loading map...</Text>
      </View>
    );
  }

  return (
    <MapView
      style={styles.map}
      initialRegion={{
        latitude: 37.78825,
        longitude: -122.4324,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      }}>
      <Marker
        coordinate={{ latitude: 37.78825, longitude: -122.4324 }}
        title="Perfect Date Spot"
        description="A romantic restaurant with amazing views"
      />
    </MapView>
  );
}

// Main map component that handles platform differences
function MapComponent() {
  if (Platform.OS === 'web') {
    return <WebMap />;
  }
  return <NativeMap />;
}

export default function MapScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.searchContainer}>
        <TouchableOpacity style={styles.searchBar}>
          <Search size={20} color="#6B7280" />
          <Text style={styles.searchPlaceholder}>Search locations...</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.mapContainer}>
        <MapComponent />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  searchContainer: {
    padding: 20,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    padding: 12,
    gap: 8,
  },
  searchPlaceholder: {
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    fontSize: 16,
  },
  mapContainer: {
    flex: 1,
    width: '100%',
    height: Dimensions.get('window').height - 150,
  },
  map: {
    width: '100%',
    height: '100%',
  },
  fallbackContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
  },
  fallbackText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#6B7280',
  },
});